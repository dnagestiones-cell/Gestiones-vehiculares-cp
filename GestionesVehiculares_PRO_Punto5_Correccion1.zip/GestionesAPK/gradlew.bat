@ECHO OFF
SET DIR=%~dp0
sh "%DIR%gradlew.sh" %*
